<?php
$_['get_order_id'] = 'Write the order number received via email example: 789';
$_['step_1_error'] = 'Please insert only number or write \'Exit\' for quit command';
$_['exit_command'] = 'Comand quited';