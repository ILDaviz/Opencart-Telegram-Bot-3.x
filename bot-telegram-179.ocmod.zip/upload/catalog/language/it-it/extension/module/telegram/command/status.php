<?php
$_['get_order_id'] = 'Inserisci il numero dell\'ordine ricevuto via email solo i numero es:758';
$_['step_1_error'] = 'Usa solo i numeri o scrivi Exit per uscire dal comando';
$_['exit_command'] = 'Comando spento con successo';