<?php
/**
 * @author		David Galet
 * @link		https://www.davidev.it
*/
class ModelExtensionModuleTelegramCommandStatus extends Model {
    public function getStatus($order_id){
        
    }
}